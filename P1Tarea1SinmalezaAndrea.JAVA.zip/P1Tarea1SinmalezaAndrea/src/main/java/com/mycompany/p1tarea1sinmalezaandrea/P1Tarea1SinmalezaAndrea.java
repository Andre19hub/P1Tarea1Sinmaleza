package com.mycompany.p1tarea1sinmalezaandrea;

import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;

public class P1Tarea1SinmalezaAndrea {
    static int t1, t2, t3;
    static final String ARCHIVO_JSON = "registro.json";
    static final String ARCHIVO_CSV = "registro.csv";

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("=== Menu de opciones ===");
            System.out.println("1. Ingreso de notas");
            System.out.println("2. Promedio");
            System.out.println("3. Leer archivo de notas CVS");
            System.out.println("4. Salir");
            System.out.print("Ingrese una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    ingresoNotas();
                    break;
                case 2:
                    promediar();
                    break;
                case 3:
                    leerArchivo();
                    break;
                case 4:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opcion incorrecta, ingrese de nuevo.");
            }
        } while (opcion != 4);

        scanner.close();
    }

    public static void ingresoNotas() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la nota de la Tarea 1 (0-20): ");
        t1 = scanner.nextInt();
        while (t1 < 0 || t1 > 20) {
            System.out.print("La nota que ingreso esta fuera del rango. Ingrese de nuevo: ");
            t1 = scanner.nextInt();
        }

        System.out.print("Ingrese la nota de la Tarea 2 (0-20): ");
        t2 = scanner.nextInt();
        while (t2 < 0 || t2 > 20) {
            System.out.print("La nota que ingreso esta fuera del rango. Ingrese de nuevo: ");
            t2 = scanner.nextInt();
        }

        System.out.print("Ingrese la nota de la Tarea 3 (0-20): ");
        t3 = scanner.nextInt();
        while (t3 < 0 || t3 > 20) {
            System.out.print("La nota que ingreso esta fuera del rango. Ingrese de nuevo: ");
            t3 = scanner.nextInt();
        }

        guardarNotasCsv();
        guardarNotasJson();
    }

    public static void guardarNotasCsv() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_CSV, true))) {
            File file = new File(ARCHIVO_CSV);
            if (file.length() == 0) {
            }

            float promedio = (t1 + t2 + t3) / 3.0f;
            String estado = (promedio >= 14) ? "Aprobado" : "Reprobado";

                       // Escribir las notas en formato CSV
            writer.write("Tarea 1: " + t1 + "\n");
            writer.write("Tarea 2: " + t2 + "\n");
            writer.write("Tarea 3: " + t3 + "\n");
            writer.write("Promedio: " + promedio + "\n");
            writer.write("Estado: " + estado + "\n");
            writer.write("\n"); // Linea en blanco para separar registros
              System.out.println("Notas, promedio y estado guardados en " + ARCHIVO_CSV);
        } catch (IOException e) {
            System.out.println("Error al guardar en archivo CSV.");
        }
    }

    public static void guardarNotasJson() {
        float promedio = (t1 + t2 + t3) / 3.0f;
        String estado = (promedio >= 14) ? "Aprobado" : "Reprobado";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_JSON))) {
            writer.write("{\n");
            writer.write("  \"Tarea 1\": " + t1 + ",\n");
            writer.write("  \"Tarea 2\": " + t2 + ",\n");
            writer.write("  \"Tarea 3\": " + t3 + ",\n");
            writer.write("  \"Promedio\": " + promedio + ",\n");
            writer.write("  \"Estado\": \"" + estado + "\"\n");
            writer.write("}");
            System.out.println("Archivo JSON guardado: " + ARCHIVO_JSON);
        } catch (IOException e) {
            System.out.println("Error al guardar en archivo JSON.");
        }
    }

    public static void leerArchivo() {
        try (BufferedReader buffer = new BufferedReader(new FileReader(ARCHIVO_CSV))) {
            System.out.println("=== Contenido del archivo " + ARCHIVO_CSV + " ===");
            String linea;
            while ((linea = buffer.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al abrir el archivo para lectura.");
        }
    }

    public static void promediar() {
        float promedio = (t1 + t2 + t3) / 3.0f;
        System.out.println("El promedio de las notas es: " + promedio);
        if (promedio >= 14) {
            System.out.println("Aprobado");
        } else {
            System.out.println("Reprobado");
        }
    }
}


