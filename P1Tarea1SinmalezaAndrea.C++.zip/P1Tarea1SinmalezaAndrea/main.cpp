#include <iostream>
#include <fstream> // Incluimos la biblioteca para manejar archivos
using namespace std;
// Declaramos funciones
void menu();
void ingresoNotas();
void promediar();
void guardarNotas();
void leerArchivo();
// Variables globales para almacenar las notas
int t1, t2, t3;

void menu() {
    int opcion;

    do {
        cout << "=== Menu de opciones ===" << endl;
        cout << "1. Ingreso de notas" << endl;
        cout << "2. Promedio" << endl;
        cout << "3. Leer archivo de notas" << endl;
        cout << "4. Salir" << endl;
        cout << "Ingrese una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                ingresoNotas();
                break;
            case 2:
                promediar();
                break;
            case 3:
                leerArchivo();
                break;
            case 4:
                cout << "Saliendo del programa... " << endl;
                break;
            default:
                cout << "Opcion incorrecta, ingrese de nuevo: " << endl;
        }
    } while (opcion != 4);
}

void ingresoNotas() {
    cout << "Ingrese la nota de la Tarea 1 (0-20): ";
    cin >> t1;
    while (t1 < 0 || t1 > 20) {
        cout << "La nota que ingreso esta fuera del rango. Ingrese de nuevo: ";
        cin >> t1;
    }

    cout << "Ingrese la nota de la Tarea 2 (0-20): ";
    cin >> t2;
    while (t2 < 0 || t2 > 20) {
        cout << "La nota que ingreso esta fuera del rango. Ingrese de nuevo: ";
        cin >> t2;
    }

    cout << "Ingrese la nota de la Tarea 3 (0-20): ";
    cin >> t3;
    while (t3 < 0 || t3 > 20) {
        cout << "La nota que ingreso esta fuera del rango. Ingrese de nuevo: ";
        cin >> t3;
    }

    guardarNotas(); // Llamamos a la funcion para guardar las notas
}

void guardarNotas() {
    ofstream archivo("registro.txt", ios::app); // Abrimos el archivo en modo append
    if (archivo.is_open()) {
        // Calculamos el promedio
        float promedio = (t1 + t2 + t3) / 3.0;
        // Determinamos si es aprobado o reprobado
        string estado = (promedio >= 14) ? "Aprobado" : "Reprobado";
        archivo << "Tarea 1: " << t1 << endl;
        archivo << "Tarea 2: " << t2 << endl;
        archivo << "Tarea 3: " << t3 << endl;
        archivo << "Promedio: " << promedio << endl;
        archivo << "Estado: " << estado << endl << endl;
        archivo.close(); // Cerramos el archivo
        cout << "Notas, promedio y estado guardados en registro.txt" << endl;
    } else {
        cout << "Error al abrir el archivo." << endl;
    }
}

void leerArchivo() {
    ifstream archivo("registro.txt"); // Abrimos el archivo en modo lectura
    if (archivo.is_open()) {
        string linea;
        cout << "=== Contenido del archivo registro.txt ===" << endl;
        while (getline(archivo, linea)) { // Leemos linea por l�nea
            cout << linea << endl;
        }
        archivo.close(); // Cerramos el archivo
    } else {
        cout << "Error al abrir el archivo para lectura." << endl;
    }
}

void promediar() {
    float promedio = (t1 + t2 + t3) / 3.0;
    cout << "El promedio de las notas es: " << promedio << endl;
    if (promedio >= 14) {
        cout << "Aprobado" << endl;
    } else {
        cout << "Reprobado" << endl;
    }
}

int main() {
    // Llamado del menu de opciones
    menu();
    return 0;
}



